<?php
use App\Http\Controllers\EmpleadoController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\ProvedorController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//rutas de productos


Route::get('/productos', [ProductoController::class, 'index'])->name('producto.inicio');

Route::get('/productos/crear', [ProductoController::class, 'create'])->name('producto.crear');

Route::post('/productos/guardar', [ProductoController::class, 'store'])->name('producto.store');

Route::get('/productos/editar/{id}', [ProductoController::class, 'edit'])->name('producto.edit');

Route::put('/productos/update/{id}', [ProductoController::class, 'update'])->name('producto.update');

Route::get('/producto/delete/{id}', [ProductoController::class, 'delete'])->name('producto.delete');

//rutas de provedores

Route::get('/provedor', [ProvedorController::class, 'index'])->name('provedor.inicio');

Route::get('/provedor/crear', [ProvedorController::class, 'create'])->name('provedor.crear');

Route::post('/provedor/guardar', [ProvedorController::class, 'store'])->name('provedor.store');

Route::get('/provedor/editar/{id}', [ProvedorController::class, 'edit'])->name('provedor.edit');

Route::put('/provedor/update/{id}', [ProvedorController::class, 'update'])->name('provedor.update');

Route::get('/provedor/delete/{id}', [ProvedorController::class, 'delete'])->name('provedor.delete');



//rutas de empleados
Route::get('/empleados', [EmpleadoController::class, 'index'])->name('empleado.inicio');

Route::get('/empleados/crear', [EmpleadoController::class, 'create'])->name('empleado.crear');

Route::post('/empleados/guardar', [EmpleadoController::class, 'store'])->name('empleado.store');

Route::get('/empleados/editar/{id}', [EmpleadoController::class, 'edit'])->name('empleado.edit');

Route::put('/empleados/update/{id}', [EmpleadoController::class, 'update'])->name('empleado.update');

Route::get('/empleado/delete/{id}', [EmpleadoController::class, 'delete'])->name('empleado.delete');
