<?php

namespace App\Http\Controllers;
use App\Models\Provedor;
use Illuminate\Http\Request;

class ProvedorController extends Controller
{
    public function index(){
        $provedor = Provedor::all();
        return view('provedor', compact('provedor'));
    }

    public function create(){
        return view('crearprovedor');
    }
/*
   $table->integer("idprovedor")->primaryKey();;
            $table->string("nombre");
            $table->string("apellido");
                        $table->date("fechaRegistro");
                        $table->string("telefono");
                        $table->string("correo");
 **/
    public function store(Request $request){
        $nvoprovedor = new Provedor();
        $nvoprovedor->idprovedor = $request->input('idprovedor');
        $nvoprovedor->nombre = $request->input('nombre');
        $nvoprovedor->apellido = $request->input('apellido');
        $nvoprovedor->telefono  = $request->input('telefono');
        $nvoprovedor->correo  = $request->input('correo');
        $nvoprovedor->fechaRegistro = $request->input('fechaRegistro');


        $nvoprovedor->save();
        //return $name2;
    }

    public function edit($id){
        $provedor=Provedor::find($id);
        return view('editarprovedor', compact('provedor'));
    }

    public function update(Request $request, $id){
        $provedor = Provedor::find($id);
        $provedor->nombre = $request->input('nombre');
        $provedor->apellido = $request->input('apellido');
        $provedor->telefono  = $request->input('telefono');
        $provedor->correo  = $request->input('correo');
        $provedor->fechaRegistro = $request->input('fechaRegistro');


        $provedor->update();

         return redirect()->route('provedor.inicio');
    }

    public function delete($id){
        $provedor = Provedor::find($id);
        return view('eliminar', compact('provedor'));
    }
}
