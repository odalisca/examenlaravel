<?php

namespace App\Http\Controllers;
use App\Models\Empleado;

use Illuminate\Http\Request;

class EmpleadoController extends Controller
{
    public function index(){
        $empleado = Empleado::all();
        return view('empleado', compact('empleado'));
    }

    public function create(){
        return view('crearempleado');
    }

    public function store(Request $request){
        $nvoempleado = new Empleado();
        $nvoempleado->idprestamo = $request->input('idprestamo');
        $nvoempleado->nombre = $request->input('nombre');
        $nvoempleado->apellido = $request->input('apellido');
        $nvoempleado->salario  = $request->input('salario');
        $nvoempleado->fechaingreso = $request->input('fechaingreso');


        $nvoempleado->save();
        //return $name2;
    }
/*
    public function edit($id){
        $empleado =Empleado::find($id);
        return view('editarempleado', compact('empleado'));
    }

    public function update(Request $request, $id){
        $empleado = Empleado::find($id);
        $empleado->nombre = $request->input('nombre');
        $empleado->apellido = $request->input('apellido');
        $empleado->salario  = $request->input('salario');
        $empleado->fechaingreso = $request->input('fechaingreso');


        $empleado->update();

         return redirect()->route('empleado.inicio');
    }

    public function delete($id){
        $empleado = Empleado::find($id);
        return view('eliminar', compact('empleado'));
    }
    **/
}
