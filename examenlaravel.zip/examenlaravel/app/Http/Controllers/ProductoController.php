<?php

namespace App\Http\Controllers;
use App\Models\Producto;
use Illuminate\Http\Request;

class ProductoController extends Controller
{



public function index(){
    $producto = Producto::all();
    return view('producto', compact('producto'));
}

public function create(){
    return view('crearproducto');
}

/*
     $table->id();
                        $table->string("descripcion");
                        $table->double("precio");
            $table->integer("stock");
            $table->boolean('pagaIsv')->nullable()->default(false);


**/

public function store(Request $request){
    $nvoproducto = new Producto();
   // $nvoproducto->id = $request->input('id');
    $nvoproducto->descripcion = $request->input('descripcion');
    $nvoproducto->precio = $request->input('precio');
    $nvoproducto->stock  = $request->input('stock');
    $nvoproducto->pagaIsv  = $request->input('pagaIsv');



    $nvoproducto->save();
    //return $name2;
}

public function edit($id){
    $producto=Producto::find($id);
    return view('editarproducto', compact('producto'));
}

public function update(Request $request, $id){
    $nvoproducto = Producto::find($id);
    $nvoproducto->descripcion = $request->input('descripcion');
    $nvoproducto->precio = $request->input('precio');
    $nvoproducto->stock  = $request->input('stock');
    $nvoproducto->pagaIsv  = $request->input('pagaIsv');


    $nvoproducto->update();

     return redirect()->route('producto.inicio');
}

public function delete($id){
    $producto = Producto::find($id);
    return view('eliminar', compact('producto'));
}


}
