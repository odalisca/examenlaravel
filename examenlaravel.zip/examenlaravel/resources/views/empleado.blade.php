<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>empleados</title>
</head>
<body>

  <div class="container">
    <h1>empleados</h1>
    </p>

    <div>
        <a class="btn btn-primary" href="{{ route('empleado.crear') }}">Crear Nuevo empleado</a>
    </div>

    </p>

    <table class="table">
        <thead>
          <tr>
            <th scope="col">idempleado</th>
            <th scope="col">nombre</th>
            <th scope="col">apellido</th>
            <th scope="col">salario</th>
            <th scope="col">fechaingreso</th>
            <th scope="col">Editar</th>
            <th scope="col">Eliminar</th>
          </tr>
        </thead>
        <tbody>
            @foreach ($empleado as $item)
            <tr>
                <th scope="row">{{$item->idprestamo}}</th>
                <td>{{$item->nombre}}</td>
                <td>{{$item->apellido}}</td>
                <td>{{$item->salario}}</td>
                <td>{{$item->fechaingreso}}</td>
                <td>
                  <a class="btn btn-success" href="{{ route('empleado.edit', $item->idprestamo) }}">Editar</a>
                </td>
                <td>
                  <a class="btn btn-danger" href="{{ route('empleado.delete', $item->idprestamo) }}">Eliminar</a>
                </td>
            </tr>
            @endforeach

        </tbody>
      </table>
  </div>

</body>
</html>
