<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>provedor</title>
</head>
<body>

  <div class="container">
    <h1>provedores</h1>
    </p>

    <div>
        <a class="btn btn-primary" href="{{ route('provedor.crear') }}">Crear Nuevo provedor</a>
    </div>

    </p>

    <table class="table">
        <thead>
          <tr>
            <th scope="col">idprovedor</th>
            <th scope="col">nombre</th>
            <th scope="col">Apellido</th>
            <th scope="col">fechaongreso</th>
            <th scope="col">telefono</th>
            <th scope="col">correo</th>
            <th scope="col">Editar</th>
            <th scope="col">Eliminar</th>
          </tr>
        </thead>
        <tbody>
            @foreach ($provedor as $item)
            <tr>
                <th scope="row">{{$item->idprovedor}}</th>
                <td>{{$item->nombre}}</td>
                <td>{{$item->apellido}}</td>
                <td>{{$item->fechaingreso}}</td>
                <td>{{$item->telefono}}</td>
                <td>{{$item->correo}}</td>
                <td>
                  <a class="btn btn-success" href="{{ route('provedor.edit', $item->idprovedor) }}">Editar</a>
                </td>
                <td>
                  <a class="btn btn-danger" href="{{ route('provedor.delete', $item->idprovedor) }}">Eliminar</a>
                </td>
            </tr>
            @endforeach

        </tbody>
      </table>
  </div>

</body>
</html>
