<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>producto</title>
</head>
<body>

  <div class="container">
    <h1>producto</h1>
    </p>

    <div>
        <a class="btn btn-primary" href="{{ route('producto.crear') }}">Crear Nuevo producto</a>

    </p>

    <table class="table">
        <thead>
          <tr>
            <th scope="col">id</th>
            <th scope="col">descripcion</th>


            <th scope="col">precio</th>
             <th scope="col">stock</th>
             <th scope="col">pagaisv</th>
            <th scope="col">Editar</th>
            <th scope="col">Eliminar</th>
          </tr>
        </thead>
        <tbody>
            @foreach ($producto as $item)
            <tr>
                <th scope="row">{{$item->id}}</th>
                <td>{{$item->descripcion}}</td>
                <td>{{$item->precio}}</td>
                <td>{{$item->stock}}</td>
                <td>{{$item->pagaIsv}}</td>
                <td>
                  <a class="btn btn-success" href="{{ route('producto.edit', $item->codigoPelicula) }}">Editar</a>
                </td>
                <td>
                  <a class="btn btn-danger" href="{{ route('producto.delete', $item->codigoPelicula) }}">Eliminar</a>
                </td>
            </tr>
            @endforeach

        </tbody>
      </table>
  </div>

</body>
</html>
