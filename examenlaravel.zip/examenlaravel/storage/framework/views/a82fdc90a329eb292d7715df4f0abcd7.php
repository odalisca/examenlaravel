<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>producto</title>
</head>
<body>

  <div class="container">
    <h1>producto</h1>
    </p>

    <div>
        <a class="btn btn-primary" href="<?php echo e(route('producto.crear')); ?>">Crear Nuevo producto</a>

    </p>

    <table class="table">
        <thead>
          <tr>
            <th scope="col">id</th>
            <th scope="col">descripcion</th>


            <th scope="col">precio</th>
             <th scope="col">stock</th>
             <th scope="col">pagaisv</th>
            <th scope="col">Editar</th>
            <th scope="col">Eliminar</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $producto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($item->id); ?></th>
                <td><?php echo e($item->descripcion); ?></td>
                <td><?php echo e($item->precio); ?></td>
                <td><?php echo e($item->stock); ?></td>
                <td><?php echo e($item->pagaIsv); ?></td>
                <td>
                  <a class="btn btn-success" href="<?php echo e(route('producto.edit', $item->codigoPelicula)); ?>">Editar</a>
                </td>
                <td>
                  <a class="btn btn-danger" href="<?php echo e(route('producto.delete', $item->codigoPelicula)); ?>">Eliminar</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
      </table>
  </div>

</body>
</html>
<?php /**PATH C:\wamp64\www\examenlaravel\resources\views/producto.blade.php ENDPATH**/ ?>