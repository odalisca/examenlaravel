<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>productos</title>
</head>
<body>

  <div class="container">

    <h1>Creación productos</h1>

    <form method="POST" action="<?php echo e(route('producto.store')); ?>">

        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>

        <div class="row">


              <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">descripcion</label>
                <input type="text" class="form-control" name="descripcion" id="descripcion" placeholder="Another input placeholder">
              </div>
              <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">precio</label>
                <input type="text" class="form-control" name="precio" id="precio" placeholder="Another input placeholder">
              </div>
              <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">stock</label>
                <input type="text" class="form-control" name="stock" id="stock" placeholder="Another input placeholder">
              </div>
              <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">pagaIsv</label>
                <input type="text" class="form-control" name="pagaIsv" id="pagaIsv" placeholder="Another input placeholder">
              </div>


              <button type="submit" class="btn btn-success">Guardar</button>
              <a class="btn btn-secondary" data-bs-dismiss="modal" href="<?php echo e(route('producto.inicio')); ?>">Cancelar</a>

        </div>

    </form>

  </div>

</body>
</html>
<?php /**PATH C:\wamp64\www\examenlaravel\resources\views/crearproducto.blade.php ENDPATH**/ ?>